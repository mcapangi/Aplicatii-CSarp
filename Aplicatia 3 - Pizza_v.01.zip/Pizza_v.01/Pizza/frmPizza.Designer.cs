﻿namespace Pizza
{
    partial class frmPizza
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPizza));
            this.cboSortimente = new System.Windows.Forms.ComboBox();
            this.pbPizza = new System.Windows.Forms.PictureBox();
            this.gbAlegere = new System.Windows.Forms.GroupBox();
            this.lblPretCiuperci = new System.Windows.Forms.Label();
            this.lblPretPorumb = new System.Windows.Forms.Label();
            this.lblPretPui = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPretTon = new System.Windows.Forms.Label();
            this.chkCiuperci = new System.Windows.Forms.CheckBox();
            this.chkPorumb = new System.Windows.Forms.CheckBox();
            this.chkPui = new System.Windows.Forms.CheckBox();
            this.chkTon = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbMare = new System.Windows.Forms.RadioButton();
            this.rbMedie = new System.Windows.Forms.RadioButton();
            this.rbMica = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPret = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lstPret = new System.Windows.Forms.ListBox();
            this.btnComanda = new System.Windows.Forms.Button();
            this.lblComanda = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbPizza)).BeginInit();
            this.gbAlegere.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboSortimente
            // 
            this.cboSortimente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSortimente.FormattingEnabled = true;
            this.cboSortimente.Items.AddRange(new object[] {
            "Margherita",
            "Palermo",
            "Roma",
            "Vegetariana"});
            this.cboSortimente.Location = new System.Drawing.Point(51, 38);
            this.cboSortimente.Name = "cboSortimente";
            this.cboSortimente.Size = new System.Drawing.Size(195, 21);
            this.cboSortimente.TabIndex = 0;
            this.cboSortimente.SelectedIndexChanged += new System.EventHandler(this.cboSortimente_SelectedIndexChanged);
            // 
            // pbPizza
            // 
            this.pbPizza.Image = ((System.Drawing.Image)(resources.GetObject("pbPizza.Image")));
            this.pbPizza.Location = new System.Drawing.Point(51, 77);
            this.pbPizza.Name = "pbPizza";
            this.pbPizza.Size = new System.Drawing.Size(195, 160);
            this.pbPizza.TabIndex = 2;
            this.pbPizza.TabStop = false;
            // 
            // gbAlegere
            // 
            this.gbAlegere.Controls.Add(this.lblPretCiuperci);
            this.gbAlegere.Controls.Add(this.lblPretPorumb);
            this.gbAlegere.Controls.Add(this.lblPretPui);
            this.gbAlegere.Controls.Add(this.label6);
            this.gbAlegere.Controls.Add(this.label5);
            this.gbAlegere.Controls.Add(this.label4);
            this.gbAlegere.Controls.Add(this.label2);
            this.gbAlegere.Controls.Add(this.lblPretTon);
            this.gbAlegere.Controls.Add(this.chkCiuperci);
            this.gbAlegere.Controls.Add(this.chkPorumb);
            this.gbAlegere.Controls.Add(this.chkPui);
            this.gbAlegere.Controls.Add(this.chkTon);
            this.gbAlegere.Location = new System.Drawing.Point(279, 38);
            this.gbAlegere.Name = "gbAlegere";
            this.gbAlegere.Size = new System.Drawing.Size(159, 140);
            this.gbAlegere.TabIndex = 3;
            this.gbAlegere.TabStop = false;
            this.gbAlegere.Text = "Ingrediente la alegere";
            // 
            // lblPretCiuperci
            // 
            this.lblPretCiuperci.AutoSize = true;
            this.lblPretCiuperci.Location = new System.Drawing.Point(96, 113);
            this.lblPretCiuperci.Name = "lblPretCiuperci";
            this.lblPretCiuperci.Size = new System.Drawing.Size(13, 13);
            this.lblPretCiuperci.TabIndex = 4;
            this.lblPretCiuperci.Text = "1";
            // 
            // lblPretPorumb
            // 
            this.lblPretPorumb.AutoSize = true;
            this.lblPretPorumb.Location = new System.Drawing.Point(96, 83);
            this.lblPretPorumb.Name = "lblPretPorumb";
            this.lblPretPorumb.Size = new System.Drawing.Size(22, 13);
            this.lblPretPorumb.TabIndex = 4;
            this.lblPretPorumb.Text = "0,5";
            // 
            // lblPretPui
            // 
            this.lblPretPui.AutoSize = true;
            this.lblPretPui.Location = new System.Drawing.Point(96, 56);
            this.lblPretPui.Name = "lblPretPui";
            this.lblPretPui.Size = new System.Drawing.Size(22, 13);
            this.lblPretPui.TabIndex = 4;
            this.lblPretPui.Text = "1,5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(121, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "lei";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(121, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "lei";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(121, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "lei";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "lei";
            // 
            // lblPretTon
            // 
            this.lblPretTon.AutoSize = true;
            this.lblPretTon.Location = new System.Drawing.Point(96, 30);
            this.lblPretTon.Name = "lblPretTon";
            this.lblPretTon.Size = new System.Drawing.Size(13, 13);
            this.lblPretTon.TabIndex = 4;
            this.lblPretTon.Text = "2";
            // 
            // chkCiuperci
            // 
            this.chkCiuperci.AutoSize = true;
            this.chkCiuperci.Location = new System.Drawing.Point(20, 109);
            this.chkCiuperci.Name = "chkCiuperci";
            this.chkCiuperci.Size = new System.Drawing.Size(64, 17);
            this.chkCiuperci.TabIndex = 0;
            this.chkCiuperci.Text = "Ciuperci";
            this.chkCiuperci.UseVisualStyleBackColor = true;
            this.chkCiuperci.CheckedChanged += new System.EventHandler(this.chkCiuperci_CheckedChanged);
            // 
            // chkPorumb
            // 
            this.chkPorumb.AutoSize = true;
            this.chkPorumb.Location = new System.Drawing.Point(20, 82);
            this.chkPorumb.Name = "chkPorumb";
            this.chkPorumb.Size = new System.Drawing.Size(62, 17);
            this.chkPorumb.TabIndex = 0;
            this.chkPorumb.Text = "Porumb";
            this.chkPorumb.UseVisualStyleBackColor = true;
            this.chkPorumb.CheckedChanged += new System.EventHandler(this.chkPorumb_CheckedChanged);
            // 
            // chkPui
            // 
            this.chkPui.AutoSize = true;
            this.chkPui.Location = new System.Drawing.Point(20, 55);
            this.chkPui.Name = "chkPui";
            this.chkPui.Size = new System.Drawing.Size(41, 17);
            this.chkPui.TabIndex = 0;
            this.chkPui.Text = "Pui";
            this.chkPui.UseVisualStyleBackColor = true;
            this.chkPui.CheckedChanged += new System.EventHandler(this.chkPui_CheckedChanged);
            // 
            // chkTon
            // 
            this.chkTon.AutoSize = true;
            this.chkTon.Location = new System.Drawing.Point(20, 28);
            this.chkTon.Name = "chkTon";
            this.chkTon.Size = new System.Drawing.Size(45, 17);
            this.chkTon.TabIndex = 0;
            this.chkTon.Text = "Ton";
            this.chkTon.UseVisualStyleBackColor = true;
            this.chkTon.CheckedChanged += new System.EventHandler(this.chkTon_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbMare);
            this.groupBox1.Controls.Add(this.rbMedie);
            this.groupBox1.Controls.Add(this.rbMica);
            this.groupBox1.Location = new System.Drawing.Point(279, 188);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(159, 115);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dimensiune";
            // 
            // rbMare
            // 
            this.rbMare.AutoSize = true;
            this.rbMare.Location = new System.Drawing.Point(21, 81);
            this.rbMare.Name = "rbMare";
            this.rbMare.Size = new System.Drawing.Size(49, 17);
            this.rbMare.TabIndex = 0;
            this.rbMare.Text = "Mare";
            this.rbMare.UseVisualStyleBackColor = true;
            this.rbMare.CheckedChanged += new System.EventHandler(this.rbMare_CheckedChanged);
            // 
            // rbMedie
            // 
            this.rbMedie.AutoSize = true;
            this.rbMedie.Checked = true;
            this.rbMedie.Location = new System.Drawing.Point(21, 55);
            this.rbMedie.Name = "rbMedie";
            this.rbMedie.Size = new System.Drawing.Size(54, 17);
            this.rbMedie.TabIndex = 0;
            this.rbMedie.TabStop = true;
            this.rbMedie.Text = "Medie";
            this.rbMedie.UseVisualStyleBackColor = true;
            this.rbMedie.CheckedChanged += new System.EventHandler(this.rbMedie_CheckedChanged);
            // 
            // rbMica
            // 
            this.rbMica.AutoSize = true;
            this.rbMica.Location = new System.Drawing.Point(21, 28);
            this.rbMica.Name = "rbMica";
            this.rbMica.Size = new System.Drawing.Size(48, 17);
            this.rbMica.TabIndex = 0;
            this.rbMica.Text = "Mica";
            this.rbMica.UseVisualStyleBackColor = true;
            this.rbMica.CheckedChanged += new System.EventHandler(this.rbMica_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Pret: ";
            // 
            // lblPret
            // 
            this.lblPret.AutoSize = true;
            this.lblPret.Location = new System.Drawing.Point(116, 251);
            this.lblPret.Name = "lblPret";
            this.lblPret.Size = new System.Drawing.Size(13, 13);
            this.lblPret.TabIndex = 4;
            this.lblPret.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(159, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "lei";
            // 
            // lstPret
            // 
            this.lstPret.FormattingEnabled = true;
            this.lstPret.Items.AddRange(new object[] {
            "14",
            "15",
            "16",
            "17"});
            this.lstPret.Location = new System.Drawing.Point(13, 77);
            this.lstPret.Name = "lstPret";
            this.lstPret.Size = new System.Drawing.Size(32, 160);
            this.lstPret.TabIndex = 5;
            this.lstPret.Visible = false;
            // 
            // btnComanda
            // 
            this.btnComanda.Location = new System.Drawing.Point(101, 279);
            this.btnComanda.Name = "btnComanda";
            this.btnComanda.Size = new System.Drawing.Size(75, 23);
            this.btnComanda.TabIndex = 6;
            this.btnComanda.Text = "Comanda!";
            this.btnComanda.UseVisualStyleBackColor = true;
            this.btnComanda.Click += new System.EventHandler(this.btnComanda_Click);
            // 
            // lblComanda
            // 
            this.lblComanda.Location = new System.Drawing.Point(48, 318);
            this.lblComanda.Name = "lblComanda";
            this.lblComanda.Size = new System.Drawing.Size(390, 64);
            this.lblComanda.TabIndex = 4;
            this.lblComanda.Text = "Comanda in curs....";
            // 
            // frmPizza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 400);
            this.Controls.Add(this.btnComanda);
            this.Controls.Add(this.lstPret);
            this.Controls.Add(this.lblPret);
            this.Controls.Add(this.lblComanda);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.gbAlegere);
            this.Controls.Add(this.pbPizza);
            this.Controls.Add(this.cboSortimente);
            this.Name = "frmPizza";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pizza - v.01";
            this.Load += new System.EventHandler(this.frmPizza_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbPizza)).EndInit();
            this.gbAlegere.ResumeLayout(false);
            this.gbAlegere.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboSortimente;
        private System.Windows.Forms.PictureBox pbPizza;
        private System.Windows.Forms.GroupBox gbAlegere;
        private System.Windows.Forms.CheckBox chkCiuperci;
        private System.Windows.Forms.CheckBox chkPorumb;
        private System.Windows.Forms.CheckBox chkPui;
        private System.Windows.Forms.CheckBox chkTon;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbMare;
        private System.Windows.Forms.RadioButton rbMedie;
        private System.Windows.Forms.RadioButton rbMica;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPret;
        private System.Windows.Forms.Label lblPretCiuperci;
        private System.Windows.Forms.Label lblPretPorumb;
        private System.Windows.Forms.Label lblPretPui;
        private System.Windows.Forms.Label lblPretTon;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstPret;
        private System.Windows.Forms.Button btnComanda;
        private System.Windows.Forms.Label lblComanda;
    }
}

