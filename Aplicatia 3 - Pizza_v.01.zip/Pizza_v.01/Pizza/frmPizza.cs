﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza
{
    public partial class frmPizza : Form
    {
        public frmPizza()
        {
            InitializeComponent();
        }

        double pret = 0;
        

        private void frmPizza_Load(object sender, EventArgs e)
        {
            cboSortimente.SelectedIndex = 0;
        }

        private void cboSortimente_SelectedIndexChanged(object sender, EventArgs e)
        {
            pbPizza.Image = new Bitmap("img/" + cboSortimente.Text + ".jpg");
            lblPret.Text = lstPret.Items[cboSortimente.SelectedIndex].ToString();
            pret = double.Parse(lblPret.Text);

            chkCiuperci.Checked = false;
            chkPorumb.Checked = false;
            chkPui.Checked = false;
            chkTon.Checked = false;
            rbMedie.Checked = true;

            lblComanda.Text = "Comanda in curs....";
        }

        private void chkTon_CheckedChanged(object sender, EventArgs e)
        {

            if(chkTon.Checked)
            {
                pret += double.Parse(lblPretTon.Text);
            }
            else
            {
                pret -= double.Parse(lblPretTon.Text);
            }
            if (rbMica.Checked)
            {
                lblPret.Text = (pret * 3 / 4).ToString();
            }
            if (rbMedie.Checked)
            {
                lblPret.Text = pret.ToString();
            }
            if (rbMare.Checked)
            {
                lblPret.Text = (pret * 3 / 2).ToString();
            }

        }

        private void chkPui_CheckedChanged(object sender, EventArgs e)
        {

            if (chkPui.Checked)
            {
                pret += double.Parse(lblPretPui.Text);
            }
            else
            {
                pret -= double.Parse(lblPretPui.Text);
            }
            if (rbMica.Checked)
            {
                lblPret.Text = (pret * 3 / 4).ToString();
            }
            if (rbMedie.Checked)
            {
                lblPret.Text = pret.ToString();
            }
            if (rbMare.Checked)
            {
                lblPret.Text = (pret * 5 / 4).ToString();
            }
        }

        private void chkPorumb_CheckedChanged(object sender, EventArgs e)
        {

            if (chkPorumb.Checked)
            {
                pret += double.Parse(lblPretPorumb.Text);
            }
            else
            {
                pret -= double.Parse(lblPretPorumb.Text);
            }
            if (rbMica.Checked)
            {
                lblPret.Text = (pret * 3 / 4).ToString();
            }
            if (rbMedie.Checked)
            {
                lblPret.Text = pret.ToString();
            }
            if (rbMare.Checked)
            {
                lblPret.Text = (pret * 5 / 4).ToString();
            }
        }

        private void chkCiuperci_CheckedChanged(object sender, EventArgs e)
        {

            if (chkCiuperci.Checked)
            {
                pret += double.Parse(lblPretCiuperci.Text);
            }
            else
            {
                pret -= double.Parse(lblPretCiuperci.Text);
            }
            if (rbMica.Checked)
            {
                lblPret.Text = (pret * 3 / 4).ToString();
            }
            if (rbMedie.Checked)
            {
                lblPret.Text = pret.ToString();
            }
            if (rbMare.Checked)
            {
                lblPret.Text = (pret * 5 / 4).ToString();
            }
        }

        private void rbMica_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMica.Checked)
            {
                lblPret.Text = (pret * 3 / 4).ToString();
            }
            if (rbMedie.Checked)
            {
                lblPret.Text = pret.ToString();
            }
            if (rbMare.Checked)
            {
                lblPret.Text = (pret * 5 / 4).ToString();
            }
        }

        private void rbMedie_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMica.Checked)
            {
                lblPret.Text = (pret * 3 / 4).ToString();
            }
            if (rbMedie.Checked)
            {
                lblPret.Text = pret.ToString();
            }
            if (rbMare.Checked)
            {
                lblPret.Text = (pret * 5 / 4).ToString();
            }
        }

        private void rbMare_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMica.Checked)
            {
                lblPret.Text = (pret * 3 / 4).ToString();
            }
            if (rbMedie.Checked)
            {
                lblPret.Text = pret.ToString();
            }
            if (rbMare.Checked)
            {
                lblPret.Text = (pret * 5 / 4).ToString();
            }
        }

        private void btnComanda_Click(object sender, EventArgs e)
        {
            lblComanda.Text = "Ati comandat o pizza " + cboSortimente.Text;

            if (rbMica.Checked)
                lblComanda.Text += " mica.";
            if (rbMedie.Checked)
                lblComanda.Text += " medie.";
            if (rbMare.Checked)
                lblComanda.Text += " mare.";

            lblComanda.Text += "\r\nIngrediente la alegere: ";
            if(chkTon.Checked)
                lblComanda.Text += "ton ";
            if (chkPui.Checked)
                lblComanda.Text += "pui ";
            if (chkCiuperci.Checked)
                lblComanda.Text += "ciuperci ";
            if (chkPorumb.Checked)
                lblComanda.Text += "porumb ";
            lblComanda.Text += "\r\nTotal: "+lblPret.Text+" lei.";

        }
    }
}
