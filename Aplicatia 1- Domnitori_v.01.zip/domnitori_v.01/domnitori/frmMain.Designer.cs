﻿namespace domnitori
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pnlCuprins = new System.Windows.Forms.Panel();
            this.lblConst = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.lblMircea = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.lblStefan = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.lblMihai = new System.Windows.Forms.Label();
            this.pnlStefan = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pbSM1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbtCitesteSM = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlMircea = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblCitesteMB = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pnlMihai = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblCItesteMV = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.pnlConst = new System.Windows.Forms.Panel();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblCitesteCB = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.pnlCuprins.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.pnlStefan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSM1)).BeginInit();
            this.pnlMircea.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.pnlMihai.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.pnlConst.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCuprins
            // 
            this.pnlCuprins.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlCuprins.BackgroundImage")));
            this.pnlCuprins.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCuprins.Controls.Add(this.lblConst);
            this.pnlCuprins.Controls.Add(this.pictureBox14);
            this.pnlCuprins.Controls.Add(this.pictureBox15);
            this.pnlCuprins.Controls.Add(this.lblMircea);
            this.pnlCuprins.Controls.Add(this.pictureBox11);
            this.pnlCuprins.Controls.Add(this.lblStefan);
            this.pnlCuprins.Controls.Add(this.pictureBox6);
            this.pnlCuprins.Controls.Add(this.lblMihai);
            this.pnlCuprins.Location = new System.Drawing.Point(25, 58);
            this.pnlCuprins.Name = "pnlCuprins";
            this.pnlCuprins.Size = new System.Drawing.Size(239, 460);
            this.pnlCuprins.TabIndex = 0;
            // 
            // lblConst
            // 
            this.lblConst.BackColor = System.Drawing.Color.Transparent;
            this.lblConst.Font = new System.Drawing.Font("Chaparral Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConst.Location = new System.Drawing.Point(14, 344);
            this.lblConst.Name = "lblConst";
            this.lblConst.Size = new System.Drawing.Size(122, 85);
            this.lblConst.TabIndex = 0;
            this.lblConst.Text = "Constantin Brâncoveanu (1654-1714)";
            this.lblConst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblConst.Click += new System.EventHandler(this.lblConst_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(154, 344);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(66, 85);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 0;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(154, 231);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(66, 94);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // lblMircea
            // 
            this.lblMircea.BackColor = System.Drawing.Color.Transparent;
            this.lblMircea.Font = new System.Drawing.Font("Chaparral Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMircea.Location = new System.Drawing.Point(14, 25);
            this.lblMircea.Name = "lblMircea";
            this.lblMircea.Size = new System.Drawing.Size(136, 83);
            this.lblMircea.TabIndex = 0;
            this.lblMircea.Text = "Mircea cel Bătrân (1355-1418)";
            this.lblMircea.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMircea.Click += new System.EventHandler(this.lblMircea_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(157, 21);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(63, 87);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            // 
            // lblStefan
            // 
            this.lblStefan.BackColor = System.Drawing.Color.Transparent;
            this.lblStefan.Font = new System.Drawing.Font("Chaparral Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStefan.Location = new System.Drawing.Point(14, 122);
            this.lblStefan.Name = "lblStefan";
            this.lblStefan.Size = new System.Drawing.Size(122, 92);
            this.lblStefan.TabIndex = 0;
            this.lblStefan.Text = "Ștefan cel Mare (1438-1504)";
            this.lblStefan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStefan.Click += new System.EventHandler(this.lblStefan_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(161, 122);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(56, 92);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // lblMihai
            // 
            this.lblMihai.BackColor = System.Drawing.Color.Transparent;
            this.lblMihai.Font = new System.Drawing.Font("Chaparral Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMihai.Location = new System.Drawing.Point(14, 245);
            this.lblMihai.Name = "lblMihai";
            this.lblMihai.Size = new System.Drawing.Size(122, 80);
            this.lblMihai.TabIndex = 0;
            this.lblMihai.Text = "Mihai Viteazul (1558-1601)";
            this.lblMihai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMihai.Click += new System.EventHandler(this.lblMihai_Click);
            // 
            // pnlStefan
            // 
            this.pnlStefan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStefan.BackgroundImage")));
            this.pnlStefan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlStefan.Controls.Add(this.pictureBox3);
            this.pnlStefan.Controls.Add(this.pictureBox2);
            this.pnlStefan.Controls.Add(this.pictureBox1);
            this.pnlStefan.Controls.Add(this.pbSM1);
            this.pnlStefan.Controls.Add(this.label7);
            this.pnlStefan.Controls.Add(this.label6);
            this.pnlStefan.Controls.Add(this.lbtCitesteSM);
            this.pnlStefan.Controls.Add(this.label10);
            this.pnlStefan.Controls.Add(this.label9);
            this.pnlStefan.Controls.Add(this.label8);
            this.pnlStefan.Controls.Add(this.label5);
            this.pnlStefan.Location = new System.Drawing.Point(12, 533);
            this.pnlStefan.Name = "pnlStefan";
            this.pnlStefan.Size = new System.Drawing.Size(40, 26);
            this.pnlStefan.TabIndex = 0;
            this.pnlStefan.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(289, 378);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(105, 78);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(159, 378);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(113, 80);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(17, 380);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pbSM1
            // 
            this.pbSM1.Image = ((System.Drawing.Image)(resources.GetObject("pbSM1.Image")));
            this.pbSM1.Location = new System.Drawing.Point(26, 65);
            this.pbSM1.Name = "pbSM1";
            this.pbSM1.Size = new System.Drawing.Size(123, 201);
            this.pbSM1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSM1.TabIndex = 0;
            this.pbSM1.TabStop = false;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(391, 102);
            this.label7.TabIndex = 0;
            this.label7.Text = resources.GetString("label7.Text");
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(155, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(258, 212);
            this.label6.TabIndex = 0;
            this.label6.Text = resources.GetString("label6.Text");
            // 
            // lbtCitesteSM
            // 
            this.lbtCitesteSM.AutoSize = true;
            this.lbtCitesteSM.BackColor = System.Drawing.Color.Transparent;
            this.lbtCitesteSM.Font = new System.Drawing.Font("Chaparral Pro", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtCitesteSM.Location = new System.Drawing.Point(268, 486);
            this.lbtCitesteSM.Name = "lbtCitesteSM";
            this.lbtCitesteSM.Size = new System.Drawing.Size(145, 19);
            this.lbtCitesteSM.TabIndex = 0;
            this.lbtCitesteSM.Text = "[Citește mai mult...]";
            this.lbtCitesteSM.Click += new System.EventHandler(this.lbtCitesteSM_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(285, 463);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 18);
            this.label10.TabIndex = 0;
            this.label10.Text = "Mănăstirea Neamț";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(147, 463);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(134, 18);
            this.label9.TabIndex = 0;
            this.label9.Text = "Mănăstirea Voroneț";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 463);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 18);
            this.label8.TabIndex = 0;
            this.label8.Text = "Mănăstirea Putna";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Chaparral Pro", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(155, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Ștefan cel Mare";
            // 
            // pnlMircea
            // 
            this.pnlMircea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlMircea.BackgroundImage")));
            this.pnlMircea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMircea.Controls.Add(this.pictureBox4);
            this.pnlMircea.Controls.Add(this.pictureBox5);
            this.pnlMircea.Controls.Add(this.pictureBox7);
            this.pnlMircea.Controls.Add(this.label11);
            this.pnlMircea.Controls.Add(this.label12);
            this.pnlMircea.Controls.Add(this.lblCitesteMB);
            this.pnlMircea.Controls.Add(this.label13);
            this.pnlMircea.Controls.Add(this.label14);
            this.pnlMircea.Controls.Add(this.label17);
            this.pnlMircea.Location = new System.Drawing.Point(280, 30);
            this.pnlMircea.Name = "pnlMircea";
            this.pnlMircea.Size = new System.Drawing.Size(430, 510);
            this.pnlMircea.TabIndex = 0;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(26, 378);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(120, 99);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(159, 378);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(118, 99);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(26, 65);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(120, 152);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(22, 220);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(391, 155);
            this.label11.TabIndex = 0;
            this.label11.Text = resources.GetString("label11.Text");
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(155, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(258, 173);
            this.label12.TabIndex = 0;
            this.label12.Text = resources.GetString("label12.Text");
            // 
            // lblCitesteMB
            // 
            this.lblCitesteMB.AutoSize = true;
            this.lblCitesteMB.BackColor = System.Drawing.Color.Transparent;
            this.lblCitesteMB.Font = new System.Drawing.Font("Chaparral Pro", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCitesteMB.Location = new System.Drawing.Point(278, 486);
            this.lblCitesteMB.Name = "lblCitesteMB";
            this.lblCitesteMB.Size = new System.Drawing.Size(145, 19);
            this.lblCitesteMB.TabIndex = 0;
            this.lblCitesteMB.Text = "[Citește mai mult...]";
            this.lblCitesteMB.Click += new System.EventHandler(this.lblCitesteMB_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(22, 473);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(131, 18);
            this.label13.TabIndex = 0;
            this.label13.Text = "Batalia de la Rovine";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(152, 474);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(142, 18);
            this.label14.TabIndex = 0;
            this.label14.Text = "Batalia de la Nicopole";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Chaparral Pro", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(155, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(153, 23);
            this.label17.TabIndex = 0;
            this.label17.Text = "Mircea cel Bătrân";
            // 
            // pnlMihai
            // 
            this.pnlMihai.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlMihai.BackgroundImage")));
            this.pnlMihai.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMihai.Controls.Add(this.pictureBox8);
            this.pnlMihai.Controls.Add(this.pictureBox9);
            this.pnlMihai.Controls.Add(this.pictureBox10);
            this.pnlMihai.Controls.Add(this.label15);
            this.pnlMihai.Controls.Add(this.label16);
            this.pnlMihai.Controls.Add(this.lblCItesteMV);
            this.pnlMihai.Controls.Add(this.label20);
            this.pnlMihai.Controls.Add(this.label21);
            this.pnlMihai.Controls.Add(this.label22);
            this.pnlMihai.Location = new System.Drawing.Point(77, 531);
            this.pnlMihai.Name = "pnlMihai";
            this.pnlMihai.Size = new System.Drawing.Size(50, 28);
            this.pnlMihai.TabIndex = 0;
            this.pnlMihai.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(214, 341);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(196, 122);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(17, 339);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(188, 121);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(26, 65);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(145, 201);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(22, 275);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(391, 48);
            this.label15.TabIndex = 0;
            this.label15.Text = "Înainte de a ajunge pe tron, ca boier, a deținut dregătoriile de bănișor de Streh" +
    "aia, stolnic domnesc și ban al Craiovei.\r\n";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(177, 63);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(236, 212);
            this.label16.TabIndex = 0;
            this.label16.Text = resources.GetString("label16.Text");
            // 
            // lblCItesteMV
            // 
            this.lblCItesteMV.AutoSize = true;
            this.lblCItesteMV.BackColor = System.Drawing.Color.Transparent;
            this.lblCItesteMV.Font = new System.Drawing.Font("Chaparral Pro", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCItesteMV.Location = new System.Drawing.Point(268, 486);
            this.lblCItesteMV.Name = "lblCItesteMV";
            this.lblCItesteMV.Size = new System.Drawing.Size(145, 19);
            this.lblCItesteMV.TabIndex = 0;
            this.lblCItesteMV.Text = "[Citește mai mult...]";
            this.lblCItesteMV.Click += new System.EventHandler(this.lblCItesteMV_Click);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(214, 463);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(196, 23);
            this.label20.TabIndex = 0;
            this.label20.Text = "Uciderea lui Mihai Viteazul";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(17, 463);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(188, 18);
            this.label21.TabIndex = 0;
            this.label21.Text = "Intrarea în Alba-Iulia";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Chaparral Pro", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(155, 25);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(131, 23);
            this.label22.TabIndex = 0;
            this.label22.Text = "Mihai Viteazul";
            // 
            // pnlConst
            // 
            this.pnlConst.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlConst.BackgroundImage")));
            this.pnlConst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlConst.Controls.Add(this.pictureBox12);
            this.pnlConst.Controls.Add(this.pictureBox13);
            this.pnlConst.Controls.Add(this.label18);
            this.pnlConst.Controls.Add(this.label19);
            this.pnlConst.Controls.Add(this.lblCitesteCB);
            this.pnlConst.Controls.Add(this.label26);
            this.pnlConst.Controls.Add(this.label27);
            this.pnlConst.Location = new System.Drawing.Point(142, 531);
            this.pnlConst.Name = "pnlConst";
            this.pnlConst.Size = new System.Drawing.Size(53, 28);
            this.pnlConst.TabIndex = 0;
            this.pnlConst.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(77, 336);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(290, 147);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(26, 65);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(123, 152);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 0;
            this.pictureBox13.TabStop = false;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(22, 238);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(391, 100);
            this.label18.TabIndex = 0;
            this.label18.Text = resources.GetString("label18.Text");
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(155, 63);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(258, 175);
            this.label19.TabIndex = 0;
            this.label19.Text = resources.GetString("label19.Text");
            // 
            // lblCitesteCB
            // 
            this.lblCitesteCB.AutoSize = true;
            this.lblCitesteCB.BackColor = System.Drawing.Color.Transparent;
            this.lblCitesteCB.Font = new System.Drawing.Font("Chaparral Pro", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCitesteCB.Location = new System.Drawing.Point(268, 486);
            this.lblCitesteCB.Name = "lblCitesteCB";
            this.lblCitesteCB.Size = new System.Drawing.Size(145, 19);
            this.lblCitesteCB.TabIndex = 0;
            this.lblCitesteCB.Text = "[Citește mai mult...]";
            this.lblCitesteCB.Click += new System.EventHandler(this.lblCitesteCB_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Chaparral Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(74, 487);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(161, 18);
            this.label26.TabIndex = 0;
            this.label26.Text = "Martiriul Brâncovenilor ";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Chaparral Pro", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(155, 25);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(212, 23);
            this.label27.TabIndex = 0;
            this.label27.Text = "Constantin Brâncoveanu";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(737, 564);
            this.Controls.Add(this.pnlMircea);
            this.Controls.Add(this.pnlMihai);
            this.Controls.Add(this.pnlConst);
            this.Controls.Add(this.pnlStefan);
            this.Controls.Add(this.pnlCuprins);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Domnitori români";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.pnlCuprins.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.pnlStefan.ResumeLayout(false);
            this.pnlStefan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSM1)).EndInit();
            this.pnlMircea.ResumeLayout(false);
            this.pnlMircea.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.pnlMihai.ResumeLayout(false);
            this.pnlMihai.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.pnlConst.ResumeLayout(false);
            this.pnlConst.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlCuprins;
        private System.Windows.Forms.Panel pnlStefan;
        private System.Windows.Forms.Label lblConst;
        private System.Windows.Forms.Label lblMircea;
        private System.Windows.Forms.Label lblStefan;
        private System.Windows.Forms.Label lblMihai;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbSM1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbtCitesteSM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnlMircea;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblCitesteMB;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel pnlMihai;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblCItesteMV;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel pnlConst;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblCitesteCB;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}

