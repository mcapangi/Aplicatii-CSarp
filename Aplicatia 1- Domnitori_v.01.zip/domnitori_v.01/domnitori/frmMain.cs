﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace domnitori
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void lbtCitesteSM_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://ro.wikipedia.org/wiki/%C8%98tefan_cel_Mare");
        }

        private void lblCitesteMB_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://ro.wikipedia.org/wiki/Mircea_cel_B%C4%83tr%C3%A2n");
        }

        private void lblCItesteMV_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://ro.wikipedia.org/wiki/Mihai_Viteazul");
        }

        private void lblCitesteCB_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://ro.wikipedia.org/wiki/Constantin_Br%C3%A2ncoveanu");
        }

        private void lblMircea_Click(object sender, EventArgs e)
        {
            pnlMircea.Visible = true;
            pnlStefan.Visible = false;
            pnlMihai.Visible = false;
            pnlConst.Visible = false;
        }

        private void lblStefan_Click(object sender, EventArgs e)
        {
            pnlMircea.Visible = false;
            pnlStefan.Visible = true;
            pnlMihai.Visible = false;
            pnlConst.Visible = false;
        }
        private void lblMihai_Click(object sender, EventArgs e)
        {
            pnlMircea.Visible =false;
            pnlStefan.Visible = false;
            pnlMihai.Visible =  true;
            pnlConst.Visible = false;
        }

        private void lblConst_Click(object sender, EventArgs e)
        {
            pnlMircea.Visible = false;
            pnlStefan.Visible = false;
            pnlMihai.Visible = false;
            pnlConst.Visible = true;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            pnlMihai.Location = pnlStefan.Location = pnlConst.Location = pnlMircea.Location;
            pnlMihai.Size = pnlStefan.Size = pnlConst.Size = pnlMircea.Size;

        }
    }
}
