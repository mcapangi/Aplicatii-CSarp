﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;

namespace PrezentareaMea
{
    public partial class frmPrezentare : Form
    {
        int carti = 0, filme = 0, orase = 0;

        public frmPrezentare()
        {
            InitializeComponent();
        }


        private void frmPrezentare_Load(object sender, EventArgs e)
        {
            lstCalatorii.Size = lstFilme.Size = lstCarti.Size;
            lstCalatorii.Location = lstFilme.Location = lstCarti.Location;

            cboPasiuni.SelectedIndex = 0;
        }

       //------------------------------------------------------------Afisare lista optiuni in functie de pasiunea selectata
        private void cboPasiuni_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstCarti.Visible = false;
            lstFilme.Visible = false;
            lstCalatorii.Visible = false;

            chk1.Checked = false;
            chk2.Checked = false;
            chk3.Checked = false;

            carti = filme = orase = 0;

            if (cboPasiuni.SelectedIndex==0)
            {
                lstCarti.Visible = true;
                pb9.Image = new Bitmap("img/literatura/lit1.jpg");
                pb10.Image = new Bitmap("img/literatura/lit2.jpg");
                pb11.Image = new Bitmap("img/literatura/lit3.jpg");
            }
            if (cboPasiuni.SelectedIndex == 1)
            {
                lstFilme.Visible = true;
                pb9.Image = new Bitmap("img/filme/film1.jpg");
                pb10.Image = new Bitmap("img/filme/film2.jpg");
                pb11.Image = new Bitmap("img/filme/film3.jpg");
            }
            if (cboPasiuni.SelectedIndex == 2)
            {
                lstCalatorii.Visible = true;
                pb9.Image = new Bitmap("img/calatorii/berlin.jpg");
                pb10.Image = new Bitmap("img/calatorii/paris.jpg");
                pb11.Image = new Bitmap("img/calatorii/viena.jpg");
            }
        }

        //--------------------------------------------------Like-uri
        private void chk1_Click(object sender, EventArgs e)
        {
            //-------------------------------------------Carti
            if (cboPasiuni.SelectedIndex == 0)     
            {
                if (chk1.Checked == true)
                    carti++;
                else
                    carti--;

                lblCateCarti.Text = carti.ToString();
            }

            //-------------------------------------------Filme
            if (cboPasiuni.SelectedIndex == 1)    
            {
                if (chk1.Checked == true)
                    filme++;
                else
                    filme--;
                lblCateFilme.Text = filme.ToString();
            }

            //-------------------------------------------Calatorii
            if (cboPasiuni.SelectedIndex == 2)     
            {
                if (chk1.Checked == true)
                    orase++;
                else
                    orase--;
                lblCateOrase.Text = orase.ToString();
            }
        }

        
        private void chk2_Click(object sender, EventArgs e)
        {
            //-------------------------------------------Carti
            if (cboPasiuni.SelectedIndex == 0)    //carti
            {
                if (chk2.Checked == true)
                    carti++;
                else
                    carti--;

                lblCateCarti.Text = carti.ToString();
            }

            //-------------------------------------------Filme
            if (cboPasiuni.SelectedIndex == 1)     
            {
                if (chk2.Checked == true)
                    filme++;
                else
                    filme--;
                lblCateFilme.Text = filme.ToString();
            }

            //-------------------------------------------Calatorii
            if (cboPasiuni.SelectedIndex == 2)     
            {
                if (chk2.Checked == true)
                    orase++;
                else
                    orase--;
                lblCateOrase.Text = orase.ToString();
            }
        }

        

        private void chk3_Click(object sender, EventArgs e)
        {
            //-------------------------------------------Carti
            if (cboPasiuni.SelectedIndex == 0)    
            {
                if (chk3.Checked == true)
                    carti++;
                else
                    carti--;

                lblCateCarti.Text = carti.ToString();
            }

            //-------------------------------------------Filme
            if (cboPasiuni.SelectedIndex == 1)    //carti
            {
                if (chk3.Checked == true)
                    filme++;
                else
                    filme--;
                lblCateFilme.Text = filme.ToString();
            }

            //-------------------------------------------Calatorii
            if (cboPasiuni.SelectedIndex == 2)    //carti
            {
                if (chk3.Checked == true)
                    orase++;
                else
                    orase--;
                lblCateOrase.Text = orase.ToString();
            }
        }
        //--------------------------------------------------------Deschidere pagina internet
        private void lblLink_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", lblLink.Text);
        }

        
        //-----------------------------------------------------------Calcul compatibilitate
        private void btnCalculeaza_Click(object sender, EventArgs e)
        {
            int total = int.Parse(lblCateCarti.Text) + int.Parse(lblCateFilme.Text) + int.Parse(lblCateOrase.Text);
            int procente = total * 100 / 9;
            prgCompatibil.Value = procente;
            MessageBox.Show("Compabilitate "+procente.ToString() + " %!");
        }

        

        //-------------------------------------------------------Afisare poze mici
        private void pb1_Click(object sender, EventArgs e)
        {
            pbMare.Image = (sender as PictureBox).Image;
        }

        

        //------------------------------------------------------Schimbare culori
        private void lblRosu_Click(object sender, EventArgs e)
        {
            pnlPoze.BackColor = lblRosu.BackColor;
            pnlPasiuni.BackColor = lblRosu.BackColor;
            pnlCompatibil.BackColor = lblRosu.BackColor;
        }

       

        private void lblAlbastru_Click(object sender, EventArgs e)
        {
            pnlPoze.BackColor = lblAlbastru.BackColor;
            pnlPasiuni.BackColor = lblAlbastru.BackColor;
            pnlCompatibil.BackColor = lblAlbastru.BackColor;
        }
        private void lblNegru_Click(object sender, EventArgs e)
        {
            pnlPoze.BackColor = lblNegru.BackColor;
            pnlPasiuni.BackColor = lblNegru.BackColor;
            pnlCompatibil.BackColor = lblNegru.BackColor;
        }

        //----------------------------------------------------Animal de companie
        

        private void rbPisica_CheckedChanged(object sender, EventArgs e)
        {
            if(rbPisica.Checked)
            {
                MessageBox.Show("Ai ghicit!");
            }
        }

        private void rbCaine_CheckedChanged(object sender, EventArgs e)
        {
            if(rbCaine.Checked)
            {
                MessageBox.Show("Nu ai ghicit!");
            }
        }

        private void rbPeste_CheckedChanged(object sender, EventArgs e)
        {
            if(rbPeste.Checked)
            {
                MessageBox.Show("Nu ai ghicit!");
            }
        }

        private void rbPapagal_CheckedChanged(object sender, EventArgs e)
        {
            if (rbPapagal.Checked)
            {
                MessageBox.Show("Nu ai ghicit!");
            }
        }


        private void pbPisica_Click(object sender, EventArgs e)
        {
            rbPisica.Checked = true;
        }
        private void pbCaine_Click(object sender, EventArgs e)
        {
            rbCaine.Checked = true;
        }

        private void pbPeste_Click(object sender, EventArgs e)
        {
            rbPeste.Checked = true;
        }

        private void pbPapagal_Click(object sender, EventArgs e)
        {
            rbPapagal.Checked = true;
        }

    }
}
