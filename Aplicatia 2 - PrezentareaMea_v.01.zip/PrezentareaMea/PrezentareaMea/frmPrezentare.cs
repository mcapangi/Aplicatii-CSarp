﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;

namespace PrezentareaMea
{
    public partial class frmPrezentare : Form
    {
        int carti = 0, filme = 0, orase = 0;

        public frmPrezentare()
        {
            InitializeComponent();
        }


        private void frmPrezentare_Load(object sender, EventArgs e)
        {
            pnlCalatorii.Size = pnlFilme.Size = pnlLiteratura.Size;
            pnlCalatorii.Location = pnlFilme.Location = pnlLiteratura.Location;

            cboPasiuni.SelectedIndex = 0;
        }

       //------------------------------------------------------------Afisare lista optiuni in functie de pasiunea selectata
        private void cboPasiuni_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlLiteratura.Visible = false;
            pnlFilme.Visible = false;
            pnlCalatorii.Visible = false;


            if (cboPasiuni.SelectedIndex==0)
            {
                pnlLiteratura.Visible = true;
            }
            if (cboPasiuni.SelectedIndex == 1)
            {
                pnlFilme.Visible = true;
            }
            if (cboPasiuni.SelectedIndex == 2)
            {
                pnlCalatorii.Visible = true;
            }
        }

        //--------------------------------------------------Like-uri
        

        
       



        //--------------------------------------------------------Deschidere pagina internet
        private void lblLink_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", lblLink.Text);
        }

        
        //-----------------------------------------------------------Calcul compatibilitate
        private void btnCalculeaza_Click(object sender, EventArgs e)
        {
            int total = int.Parse(lblCateCarti.Text) + int.Parse(lblCateFilme.Text) + int.Parse(lblCateOrase.Text);
            int procente = total * 100 / 9;
            prgCompatibil.Value = procente;
            MessageBox.Show("Compabilitate "+procente.ToString() + " %!");
        }

        

        //-------------------------------------------------------Afisare poze mici
        private void pb1_Click(object sender, EventArgs e)
        {
            pbMare.Image = (sender as PictureBox).Image;
        }

        

        //------------------------------------------------------Schimbare culori
        private void lblRosu_Click(object sender, EventArgs e)
        {
            pnlPoze.BackColor = lblRosu.BackColor;
            pnlPasiuni.BackColor = lblRosu.BackColor;
            pnlCompatibil.BackColor = lblRosu.BackColor;
        }

       

        private void lblAlbastru_Click(object sender, EventArgs e)
        {
            pnlPoze.BackColor = lblAlbastru.BackColor;
            pnlPasiuni.BackColor = lblAlbastru.BackColor;
            pnlCompatibil.BackColor = lblAlbastru.BackColor;
        }
        private void lblNegru_Click(object sender, EventArgs e)
        {
            pnlPoze.BackColor = lblNegru.BackColor;
            pnlPasiuni.BackColor = lblNegru.BackColor;
            pnlCompatibil.BackColor = lblNegru.BackColor;
        }

        //----------------------------------------------------Animal de companie
        

        private void rbPisica_CheckedChanged(object sender, EventArgs e)
        {
            if(rbPisica.Checked)
            {
                MessageBox.Show("Ai ghicit!");
            }
        }

        private void rbCaine_CheckedChanged(object sender, EventArgs e)
        {
            if(rbCaine.Checked)
            {
                MessageBox.Show("Nu ai ghicit!");
            }
        }

        private void rbPeste_CheckedChanged(object sender, EventArgs e)
        {
            if(rbPeste.Checked)
            {
                MessageBox.Show("Nu ai ghicit!");
            }
        }

        private void rbPapagal_CheckedChanged(object sender, EventArgs e)
        {
            if (rbPapagal.Checked)
            {
                MessageBox.Show("Nu ai ghicit!");
            }
        }


        private void pbPisica_Click(object sender, EventArgs e)
        {
            rbPisica.Checked = true;
        }
        private void pbCaine_Click(object sender, EventArgs e)
        {
            rbCaine.Checked = true;
        }

        private void chkLit1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLit1.Checked)
                carti++;
            else
                carti--;
            lblCateCarti.Text = carti.ToString();
        }

        private void chkLit2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLit2.Checked)
                carti++;
            else
                carti--;
            lblCateCarti.Text = carti.ToString();
        }

        private void chkLit3_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLit3.Checked)
                carti++;
            else
                carti--;
            lblCateCarti.Text = carti.ToString();
        }

        private void chkFilm1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFilm1.Checked)
                filme++;
            else
                filme--;
            lblCateFilme.Text = filme.ToString();
        }

        private void chkFilm2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFilm2.Checked)
                filme++;
            else
                filme--;
            lblCateFilme.Text = filme.ToString();
        }

        private void chkFilm3_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFilm3.Checked)
                filme++;
            else
                filme--;
            lblCateFilme.Text = filme.ToString();
        }
        //-------------------------varianta generala
        private void chkCal1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox c = (sender as CheckBox);
            if (c.Checked)
                orase++;
            else
                orase--;
            lblCateOrase.Text = orase.ToString();
        }

       

        private void pbPeste_Click(object sender, EventArgs e)
        {
            rbPeste.Checked = true;
        }

        private void pbPapagal_Click(object sender, EventArgs e)
        {
            rbPapagal.Checked = true;
        }

    }
}
