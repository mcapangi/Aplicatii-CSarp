﻿namespace PrezentareaMea
{
    partial class frmPrezentare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrezentare));
            this.pbMare = new System.Windows.Forms.PictureBox();
            this.pnlPoze = new System.Windows.Forms.Panel();
            this.rbPeste = new System.Windows.Forms.RadioButton();
            this.rbPapagal = new System.Windows.Forms.RadioButton();
            this.rbCaine = new System.Windows.Forms.RadioButton();
            this.rbPisica = new System.Windows.Forms.RadioButton();
            this.pbPapagal = new System.Windows.Forms.PictureBox();
            this.pbPeste = new System.Windows.Forms.PictureBox();
            this.pbCaine = new System.Windows.Forms.PictureBox();
            this.pbPisica = new System.Windows.Forms.PictureBox();
            this.lblNegru = new System.Windows.Forms.Label();
            this.lblAlbastru = new System.Windows.Forms.Label();
            this.lblRosu = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblLink = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.pb8 = new System.Windows.Forms.PictureBox();
            this.pb7 = new System.Windows.Forms.PictureBox();
            this.pb6 = new System.Windows.Forms.PictureBox();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.pnlCompatibil = new System.Windows.Forms.Panel();
            this.btnCalculeaza = new System.Windows.Forms.Button();
            this.prgCompatibil = new System.Windows.Forms.ProgressBar();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblCateOrase = new System.Windows.Forms.Label();
            this.lblCateFilme = new System.Windows.Forms.Label();
            this.lblCateCarti = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlPasiuni = new System.Windows.Forms.Panel();
            this.cboPasiuni = new System.Windows.Forms.ComboBox();
            this.pnlLiteratura = new System.Windows.Forms.Panel();
            this.chkLit3 = new System.Windows.Forms.CheckBox();
            this.lstLiteratura = new System.Windows.Forms.ListBox();
            this.chkLit2 = new System.Windows.Forms.CheckBox();
            this.pbLit1 = new System.Windows.Forms.PictureBox();
            this.chkLit1 = new System.Windows.Forms.CheckBox();
            this.pbLit3 = new System.Windows.Forms.PictureBox();
            this.pbLit2 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lstCalatorii = new System.Windows.Forms.ListBox();
            this.lstFilme = new System.Windows.Forms.ListBox();
            this.pnlFilme = new System.Windows.Forms.Panel();
            this.chkFilm3 = new System.Windows.Forms.CheckBox();
            this.chkFilm2 = new System.Windows.Forms.CheckBox();
            this.pbFilm1 = new System.Windows.Forms.PictureBox();
            this.chkFilm1 = new System.Windows.Forms.CheckBox();
            this.pbFilm3 = new System.Windows.Forms.PictureBox();
            this.pbFilm2 = new System.Windows.Forms.PictureBox();
            this.pnlCalatorii = new System.Windows.Forms.Panel();
            this.chkCal3 = new System.Windows.Forms.CheckBox();
            this.chkCal2 = new System.Windows.Forms.CheckBox();
            this.pbCal1 = new System.Windows.Forms.PictureBox();
            this.chkCal1 = new System.Windows.Forms.CheckBox();
            this.pbCal3 = new System.Windows.Forms.PictureBox();
            this.pbCal2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbMare)).BeginInit();
            this.pnlPoze.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPapagal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCaine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPisica)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.pnlCompatibil.SuspendLayout();
            this.pnlPasiuni.SuspendLayout();
            this.pnlLiteratura.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLit2)).BeginInit();
            this.pnlFilme.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFilm1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFilm3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFilm2)).BeginInit();
            this.pnlCalatorii.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCal1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCal3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCal2)).BeginInit();
            this.SuspendLayout();
            // 
            // pbMare
            // 
            this.pbMare.Image = ((System.Drawing.Image)(resources.GetObject("pbMare.Image")));
            this.pbMare.Location = new System.Drawing.Point(127, 45);
            this.pbMare.Name = "pbMare";
            this.pbMare.Size = new System.Drawing.Size(227, 318);
            this.pbMare.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbMare.TabIndex = 0;
            this.pbMare.TabStop = false;
            // 
            // pnlPoze
            // 
            this.pnlPoze.BackColor = System.Drawing.Color.DarkRed;
            this.pnlPoze.Controls.Add(this.rbPeste);
            this.pnlPoze.Controls.Add(this.rbPapagal);
            this.pnlPoze.Controls.Add(this.rbCaine);
            this.pnlPoze.Controls.Add(this.rbPisica);
            this.pnlPoze.Controls.Add(this.pbPapagal);
            this.pnlPoze.Controls.Add(this.pbPeste);
            this.pnlPoze.Controls.Add(this.pbCaine);
            this.pnlPoze.Controls.Add(this.pbPisica);
            this.pnlPoze.Controls.Add(this.lblNegru);
            this.pnlPoze.Controls.Add(this.lblAlbastru);
            this.pnlPoze.Controls.Add(this.lblRosu);
            this.pnlPoze.Controls.Add(this.label7);
            this.pnlPoze.Controls.Add(this.label3);
            this.pnlPoze.Controls.Add(this.lblLink);
            this.pnlPoze.Controls.Add(this.label1);
            this.pnlPoze.Controls.Add(this.pb5);
            this.pnlPoze.Controls.Add(this.pb4);
            this.pnlPoze.Controls.Add(this.pb8);
            this.pnlPoze.Controls.Add(this.pb7);
            this.pnlPoze.Controls.Add(this.pb6);
            this.pnlPoze.Controls.Add(this.pb3);
            this.pnlPoze.Controls.Add(this.pb2);
            this.pnlPoze.Controls.Add(this.pb1);
            this.pnlPoze.Controls.Add(this.pbMare);
            this.pnlPoze.ForeColor = System.Drawing.Color.Snow;
            this.pnlPoze.Location = new System.Drawing.Point(23, 27);
            this.pnlPoze.Name = "pnlPoze";
            this.pnlPoze.Size = new System.Drawing.Size(367, 557);
            this.pnlPoze.TabIndex = 2;
            // 
            // rbPeste
            // 
            this.rbPeste.AutoSize = true;
            this.rbPeste.Location = new System.Drawing.Point(203, 525);
            this.rbPeste.Name = "rbPeste";
            this.rbPeste.Size = new System.Drawing.Size(52, 17);
            this.rbPeste.TabIndex = 4;
            this.rbPeste.TabStop = true;
            this.rbPeste.Text = "Peste";
            this.rbPeste.UseVisualStyleBackColor = true;
            this.rbPeste.CheckedChanged += new System.EventHandler(this.rbPeste_CheckedChanged);
            // 
            // rbPapagal
            // 
            this.rbPapagal.AutoSize = true;
            this.rbPapagal.Location = new System.Drawing.Point(281, 525);
            this.rbPapagal.Name = "rbPapagal";
            this.rbPapagal.Size = new System.Drawing.Size(64, 17);
            this.rbPapagal.TabIndex = 4;
            this.rbPapagal.TabStop = true;
            this.rbPapagal.Text = "Papagal";
            this.rbPapagal.UseVisualStyleBackColor = true;
            this.rbPapagal.CheckedChanged += new System.EventHandler(this.rbPapagal_CheckedChanged);
            // 
            // rbCaine
            // 
            this.rbCaine.AutoSize = true;
            this.rbCaine.Location = new System.Drawing.Point(116, 525);
            this.rbCaine.Name = "rbCaine";
            this.rbCaine.Size = new System.Drawing.Size(52, 17);
            this.rbCaine.TabIndex = 4;
            this.rbCaine.TabStop = true;
            this.rbCaine.Text = "Caine";
            this.rbCaine.UseVisualStyleBackColor = true;
            this.rbCaine.CheckedChanged += new System.EventHandler(this.rbCaine_CheckedChanged);
            // 
            // rbPisica
            // 
            this.rbPisica.AutoSize = true;
            this.rbPisica.Location = new System.Drawing.Point(31, 525);
            this.rbPisica.Name = "rbPisica";
            this.rbPisica.Size = new System.Drawing.Size(53, 17);
            this.rbPisica.TabIndex = 4;
            this.rbPisica.TabStop = true;
            this.rbPisica.Text = "Pisica";
            this.rbPisica.UseVisualStyleBackColor = true;
            this.rbPisica.CheckedChanged += new System.EventHandler(this.rbPisica_CheckedChanged);
            // 
            // pbPapagal
            // 
            this.pbPapagal.Image = ((System.Drawing.Image)(resources.GetObject("pbPapagal.Image")));
            this.pbPapagal.Location = new System.Drawing.Point(278, 463);
            this.pbPapagal.Name = "pbPapagal";
            this.pbPapagal.Size = new System.Drawing.Size(73, 56);
            this.pbPapagal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPapagal.TabIndex = 3;
            this.pbPapagal.TabStop = false;
            this.pbPapagal.Click += new System.EventHandler(this.pbPapagal_Click);
            // 
            // pbPeste
            // 
            this.pbPeste.Image = ((System.Drawing.Image)(resources.GetObject("pbPeste.Image")));
            this.pbPeste.Location = new System.Drawing.Point(193, 463);
            this.pbPeste.Name = "pbPeste";
            this.pbPeste.Size = new System.Drawing.Size(73, 56);
            this.pbPeste.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbPeste.TabIndex = 3;
            this.pbPeste.TabStop = false;
            this.pbPeste.Click += new System.EventHandler(this.pbPeste_Click);
            // 
            // pbCaine
            // 
            this.pbCaine.Image = ((System.Drawing.Image)(resources.GetObject("pbCaine.Image")));
            this.pbCaine.Location = new System.Drawing.Point(108, 463);
            this.pbCaine.Name = "pbCaine";
            this.pbCaine.Size = new System.Drawing.Size(73, 56);
            this.pbCaine.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCaine.TabIndex = 3;
            this.pbCaine.TabStop = false;
            this.pbCaine.Click += new System.EventHandler(this.pbCaine_Click);
            // 
            // pbPisica
            // 
            this.pbPisica.Image = ((System.Drawing.Image)(resources.GetObject("pbPisica.Image")));
            this.pbPisica.Location = new System.Drawing.Point(23, 464);
            this.pbPisica.Name = "pbPisica";
            this.pbPisica.Size = new System.Drawing.Size(73, 54);
            this.pbPisica.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbPisica.TabIndex = 3;
            this.pbPisica.TabStop = false;
            this.pbPisica.Click += new System.EventHandler(this.pbPisica_Click);
            // 
            // lblNegru
            // 
            this.lblNegru.BackColor = System.Drawing.Color.Black;
            this.lblNegru.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNegru.Location = new System.Drawing.Point(256, 391);
            this.lblNegru.Name = "lblNegru";
            this.lblNegru.Size = new System.Drawing.Size(30, 30);
            this.lblNegru.TabIndex = 2;
            this.lblNegru.Click += new System.EventHandler(this.lblNegru_Click);
            // 
            // lblAlbastru
            // 
            this.lblAlbastru.BackColor = System.Drawing.Color.MidnightBlue;
            this.lblAlbastru.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAlbastru.Location = new System.Drawing.Point(209, 391);
            this.lblAlbastru.Name = "lblAlbastru";
            this.lblAlbastru.Size = new System.Drawing.Size(30, 30);
            this.lblAlbastru.TabIndex = 2;
            this.lblAlbastru.Click += new System.EventHandler(this.lblAlbastru_Click);
            // 
            // lblRosu
            // 
            this.lblRosu.BackColor = System.Drawing.Color.Maroon;
            this.lblRosu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRosu.Location = new System.Drawing.Point(162, 391);
            this.lblRosu.Name = "lblRosu";
            this.lblRosu.Size = new System.Drawing.Size(30, 30);
            this.lblRosu.TabIndex = 2;
            this.lblRosu.Click += new System.EventHandler(this.lblRosu_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 439);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Ghici ce animal de companie am?";
            this.label7.Click += new System.EventHandler(this.lblLink_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 399);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Culorile mele favorite sunt";
            this.label3.Click += new System.EventHandler(this.lblLink_Click);
            // 
            // lblLink
            // 
            this.lblLink.AutoSize = true;
            this.lblLink.Location = new System.Drawing.Point(29, 366);
            this.lblLink.Name = "lblLink";
            this.lblLink.Size = new System.Drawing.Size(324, 13);
            this.lblLink.TabIndex = 1;
            this.lblLink.Text = "https://www.s-models.com/gallery/teens-girl/a-teens-girl/andrea-2/";
            this.lblLink.Click += new System.EventHandler(this.lblLink_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Eu sunt Andra, am 15 ani si 1.67 inaltime.";
            // 
            // pb5
            // 
            this.pb5.Image = ((System.Drawing.Image)(resources.GetObject("pb5.Image")));
            this.pb5.Location = new System.Drawing.Point(71, 215);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(51, 64);
            this.pb5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb5.TabIndex = 0;
            this.pb5.TabStop = false;
            this.pb5.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb4
            // 
            this.pb4.Image = ((System.Drawing.Image)(resources.GetObject("pb4.Image")));
            this.pb4.Location = new System.Drawing.Point(70, 132);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(51, 64);
            this.pb4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb4.TabIndex = 0;
            this.pb4.TabStop = false;
            this.pb4.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb8
            // 
            this.pb8.Image = ((System.Drawing.Image)(resources.GetObject("pb8.Image")));
            this.pb8.Location = new System.Drawing.Point(71, 299);
            this.pb8.Name = "pb8";
            this.pb8.Size = new System.Drawing.Size(51, 64);
            this.pb8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb8.TabIndex = 0;
            this.pb8.TabStop = false;
            this.pb8.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb7
            // 
            this.pb7.Image = ((System.Drawing.Image)(resources.GetObject("pb7.Image")));
            this.pb7.Location = new System.Drawing.Point(14, 299);
            this.pb7.Name = "pb7";
            this.pb7.Size = new System.Drawing.Size(51, 64);
            this.pb7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb7.TabIndex = 0;
            this.pb7.TabStop = false;
            this.pb7.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb6
            // 
            this.pb6.Image = ((System.Drawing.Image)(resources.GetObject("pb6.Image")));
            this.pb6.Location = new System.Drawing.Point(14, 215);
            this.pb6.Name = "pb6";
            this.pb6.Size = new System.Drawing.Size(51, 64);
            this.pb6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb6.TabIndex = 0;
            this.pb6.TabStop = false;
            this.pb6.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb3
            // 
            this.pb3.Image = ((System.Drawing.Image)(resources.GetObject("pb3.Image")));
            this.pb3.Location = new System.Drawing.Point(14, 132);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(51, 64);
            this.pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb3.TabIndex = 0;
            this.pb3.TabStop = false;
            this.pb3.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb2
            // 
            this.pb2.Image = ((System.Drawing.Image)(resources.GetObject("pb2.Image")));
            this.pb2.Location = new System.Drawing.Point(71, 45);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(51, 64);
            this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb2.TabIndex = 0;
            this.pb2.TabStop = false;
            this.pb2.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb1
            // 
            this.pb1.Image = ((System.Drawing.Image)(resources.GetObject("pb1.Image")));
            this.pb1.Location = new System.Drawing.Point(15, 45);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(51, 64);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb1.TabIndex = 0;
            this.pb1.TabStop = false;
            this.pb1.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pnlCompatibil
            // 
            this.pnlCompatibil.BackColor = System.Drawing.Color.DarkRed;
            this.pnlCompatibil.Controls.Add(this.btnCalculeaza);
            this.pnlCompatibil.Controls.Add(this.prgCompatibil);
            this.pnlCompatibil.Controls.Add(this.label10);
            this.pnlCompatibil.Controls.Add(this.label9);
            this.pnlCompatibil.Controls.Add(this.lblCateOrase);
            this.pnlCompatibil.Controls.Add(this.lblCateFilme);
            this.pnlCompatibil.Controls.Add(this.lblCateCarti);
            this.pnlCompatibil.Controls.Add(this.label8);
            this.pnlCompatibil.Controls.Add(this.label2);
            this.pnlCompatibil.ForeColor = System.Drawing.Color.Snow;
            this.pnlCompatibil.Location = new System.Drawing.Point(407, 362);
            this.pnlCompatibil.Name = "pnlCompatibil";
            this.pnlCompatibil.Size = new System.Drawing.Size(367, 222);
            this.pnlCompatibil.TabIndex = 2;
            // 
            // btnCalculeaza
            // 
            this.btnCalculeaza.ForeColor = System.Drawing.Color.DarkRed;
            this.btnCalculeaza.Location = new System.Drawing.Point(99, 161);
            this.btnCalculeaza.Name = "btnCalculeaza";
            this.btnCalculeaza.Size = new System.Drawing.Size(160, 21);
            this.btnCalculeaza.TabIndex = 5;
            this.btnCalculeaza.Text = "Calculeaza compatibilitate";
            this.btnCalculeaza.UseVisualStyleBackColor = true;
            this.btnCalculeaza.Click += new System.EventHandler(this.btnCalculeaza_Click);
            // 
            // prgCompatibil
            // 
            this.prgCompatibil.Location = new System.Drawing.Point(19, 188);
            this.prgCompatibil.Name = "prgCompatibil";
            this.prgCompatibil.Size = new System.Drawing.Size(336, 19);
            this.prgCompatibil.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 110);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(205, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Dintre orasele pe care le-am vizitat iti plac:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(180, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Dintre filmele mele favorite tie iti plac:\r\n";
            // 
            // lblCateOrase
            // 
            this.lblCateOrase.AutoSize = true;
            this.lblCateOrase.Location = new System.Drawing.Point(218, 110);
            this.lblCateOrase.Name = "lblCateOrase";
            this.lblCateOrase.Size = new System.Drawing.Size(13, 13);
            this.lblCateOrase.TabIndex = 1;
            this.lblCateOrase.Text = "0";
            // 
            // lblCateFilme
            // 
            this.lblCateFilme.AutoSize = true;
            this.lblCateFilme.Location = new System.Drawing.Point(193, 85);
            this.lblCateFilme.Name = "lblCateFilme";
            this.lblCateFilme.Size = new System.Drawing.Size(13, 13);
            this.lblCateFilme.TabIndex = 1;
            this.lblCateFilme.Text = "0";
            // 
            // lblCateCarti
            // 
            this.lblCateCarti.AutoSize = true;
            this.lblCateCarti.Location = new System.Drawing.Point(193, 57);
            this.lblCateCarti.Name = "lblCateCarti";
            this.lblCateCarti.Size = new System.Drawing.Size(13, 13);
            this.lblCateCarti.TabIndex = 1;
            this.lblCateCarti.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(179, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Dintre cartile mele favorite tie iti plac:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Hai sa vedem in ce masura ne potrivim! ";
            // 
            // pnlPasiuni
            // 
            this.pnlPasiuni.BackColor = System.Drawing.Color.DarkRed;
            this.pnlPasiuni.Controls.Add(this.pnlFilme);
            this.pnlPasiuni.Controls.Add(this.cboPasiuni);
            this.pnlPasiuni.Controls.Add(this.pnlCalatorii);
            this.pnlPasiuni.Controls.Add(this.pnlLiteratura);
            this.pnlPasiuni.Controls.Add(this.label12);
            this.pnlPasiuni.ForeColor = System.Drawing.Color.Snow;
            this.pnlPasiuni.Location = new System.Drawing.Point(407, 27);
            this.pnlPasiuni.Name = "pnlPasiuni";
            this.pnlPasiuni.Size = new System.Drawing.Size(367, 330);
            this.pnlPasiuni.TabIndex = 2;
            // 
            // cboPasiuni
            // 
            this.cboPasiuni.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPasiuni.FormattingEnabled = true;
            this.cboPasiuni.Items.AddRange(new object[] {
            "Literatura",
            "Filmele",
            "Calatoriile"});
            this.cboPasiuni.Location = new System.Drawing.Point(99, 20);
            this.cboPasiuni.Name = "cboPasiuni";
            this.cboPasiuni.Size = new System.Drawing.Size(238, 21);
            this.cboPasiuni.TabIndex = 2;
            this.cboPasiuni.SelectedIndexChanged += new System.EventHandler(this.cboPasiuni_SelectedIndexChanged);
            // 
            // pnlLiteratura
            // 
            this.pnlLiteratura.Controls.Add(this.chkLit3);
            this.pnlLiteratura.Controls.Add(this.lstLiteratura);
            this.pnlLiteratura.Controls.Add(this.chkLit2);
            this.pnlLiteratura.Controls.Add(this.pbLit1);
            this.pnlLiteratura.Controls.Add(this.chkLit1);
            this.pnlLiteratura.Controls.Add(this.pbLit3);
            this.pnlLiteratura.Controls.Add(this.pbLit2);
            this.pnlLiteratura.Location = new System.Drawing.Point(3, 61);
            this.pnlLiteratura.Name = "pnlLiteratura";
            this.pnlLiteratura.Size = new System.Drawing.Size(360, 255);
            this.pnlLiteratura.TabIndex = 4;
            // 
            // chkLit3
            // 
            this.chkLit3.AutoSize = true;
            this.chkLit3.Location = new System.Drawing.Point(271, 224);
            this.chkLit3.Name = "chkLit3";
            this.chkLit3.Size = new System.Drawing.Size(71, 17);
            this.chkLit3.TabIndex = 4;
            this.chkLit3.Text = "Imi place!";
            this.chkLit3.UseVisualStyleBackColor = true;
            this.chkLit3.CheckedChanged += new System.EventHandler(this.chkLit3_CheckedChanged);
            // 
            // lstLiteratura
            // 
            this.lstLiteratura.FormattingEnabled = true;
            this.lstLiteratura.Items.AddRange(new object[] {
            "Doctor Jivago, B. Pasternak",
            "Demonii, F.M. Dostoievski",
            "In cautarea oii fantastice, H. Murakami"});
            this.lstLiteratura.Location = new System.Drawing.Point(96, 12);
            this.lstLiteratura.Name = "lstLiteratura";
            this.lstLiteratura.Size = new System.Drawing.Size(238, 82);
            this.lstLiteratura.TabIndex = 3;
            // 
            // chkLit2
            // 
            this.chkLit2.AutoSize = true;
            this.chkLit2.Location = new System.Drawing.Point(145, 224);
            this.chkLit2.Name = "chkLit2";
            this.chkLit2.Size = new System.Drawing.Size(71, 17);
            this.chkLit2.TabIndex = 4;
            this.chkLit2.Text = "Imi place!";
            this.chkLit2.UseVisualStyleBackColor = true;
            this.chkLit2.CheckedChanged += new System.EventHandler(this.chkLit2_CheckedChanged);
            // 
            // pbLit1
            // 
            this.pbLit1.Image = ((System.Drawing.Image)(resources.GetObject("pbLit1.Image")));
            this.pbLit1.Location = new System.Drawing.Point(8, 112);
            this.pbLit1.Name = "pbLit1";
            this.pbLit1.Size = new System.Drawing.Size(105, 105);
            this.pbLit1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLit1.TabIndex = 0;
            this.pbLit1.TabStop = false;
            // 
            // chkLit1
            // 
            this.chkLit1.AutoSize = true;
            this.chkLit1.Location = new System.Drawing.Point(19, 224);
            this.chkLit1.Name = "chkLit1";
            this.chkLit1.Size = new System.Drawing.Size(71, 17);
            this.chkLit1.TabIndex = 4;
            this.chkLit1.Text = "Imi place!";
            this.chkLit1.UseVisualStyleBackColor = true;
            this.chkLit1.CheckedChanged += new System.EventHandler(this.chkLit1_CheckedChanged);
            // 
            // pbLit3
            // 
            this.pbLit3.Image = ((System.Drawing.Image)(resources.GetObject("pbLit3.Image")));
            this.pbLit3.Location = new System.Drawing.Point(247, 112);
            this.pbLit3.Name = "pbLit3";
            this.pbLit3.Size = new System.Drawing.Size(105, 105);
            this.pbLit3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLit3.TabIndex = 0;
            this.pbLit3.TabStop = false;
            // 
            // pbLit2
            // 
            this.pbLit2.Image = ((System.Drawing.Image)(resources.GetObject("pbLit2.Image")));
            this.pbLit2.Location = new System.Drawing.Point(127, 112);
            this.pbLit2.Name = "pbLit2";
            this.pbLit2.Size = new System.Drawing.Size(105, 105);
            this.pbLit2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLit2.TabIndex = 0;
            this.pbLit2.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Pasiunile mele ";
            // 
            // lstCalatorii
            // 
            this.lstCalatorii.FormattingEnabled = true;
            this.lstCalatorii.Items.AddRange(new object[] {
            "Berlin",
            "Paris",
            "VIena"});
            this.lstCalatorii.Location = new System.Drawing.Point(96, 12);
            this.lstCalatorii.Name = "lstCalatorii";
            this.lstCalatorii.Size = new System.Drawing.Size(238, 82);
            this.lstCalatorii.TabIndex = 3;
            // 
            // lstFilme
            // 
            this.lstFilme.FormattingEnabled = true;
            this.lstFilme.Items.AddRange(new object[] {
            "Discursul regelui",
            "Hotul de carti",
            "La vita e bella"});
            this.lstFilme.Location = new System.Drawing.Point(96, 12);
            this.lstFilme.Name = "lstFilme";
            this.lstFilme.Size = new System.Drawing.Size(238, 82);
            this.lstFilme.TabIndex = 3;
            // 
            // pnlFilme
            // 
            this.pnlFilme.Controls.Add(this.label4);
            this.pnlFilme.Controls.Add(this.chkFilm3);
            this.pnlFilme.Controls.Add(this.chkFilm2);
            this.pnlFilme.Controls.Add(this.lstFilme);
            this.pnlFilme.Controls.Add(this.pbFilm1);
            this.pnlFilme.Controls.Add(this.chkFilm1);
            this.pnlFilme.Controls.Add(this.pbFilm3);
            this.pnlFilme.Controls.Add(this.pbFilm2);
            this.pnlFilme.Location = new System.Drawing.Point(83, 27);
            this.pnlFilme.Name = "pnlFilme";
            this.pnlFilme.Size = new System.Drawing.Size(67, 30);
            this.pnlFilme.TabIndex = 4;
            // 
            // chkFilm3
            // 
            this.chkFilm3.AutoSize = true;
            this.chkFilm3.Location = new System.Drawing.Point(271, 224);
            this.chkFilm3.Name = "chkFilm3";
            this.chkFilm3.Size = new System.Drawing.Size(71, 17);
            this.chkFilm3.TabIndex = 4;
            this.chkFilm3.Text = "Imi place!";
            this.chkFilm3.UseVisualStyleBackColor = true;
            this.chkFilm3.CheckedChanged += new System.EventHandler(this.chkFilm3_CheckedChanged);
            // 
            // chkFilm2
            // 
            this.chkFilm2.AutoSize = true;
            this.chkFilm2.Location = new System.Drawing.Point(145, 224);
            this.chkFilm2.Name = "chkFilm2";
            this.chkFilm2.Size = new System.Drawing.Size(71, 17);
            this.chkFilm2.TabIndex = 4;
            this.chkFilm2.Text = "Imi place!";
            this.chkFilm2.UseVisualStyleBackColor = true;
            this.chkFilm2.CheckedChanged += new System.EventHandler(this.chkFilm2_CheckedChanged);
            // 
            // pbFilm1
            // 
            this.pbFilm1.Image = ((System.Drawing.Image)(resources.GetObject("pbFilm1.Image")));
            this.pbFilm1.Location = new System.Drawing.Point(8, 112);
            this.pbFilm1.Name = "pbFilm1";
            this.pbFilm1.Size = new System.Drawing.Size(105, 105);
            this.pbFilm1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbFilm1.TabIndex = 0;
            this.pbFilm1.TabStop = false;
            // 
            // chkFilm1
            // 
            this.chkFilm1.AutoSize = true;
            this.chkFilm1.Location = new System.Drawing.Point(28, 224);
            this.chkFilm1.Name = "chkFilm1";
            this.chkFilm1.Size = new System.Drawing.Size(71, 17);
            this.chkFilm1.TabIndex = 4;
            this.chkFilm1.Text = "Imi place!";
            this.chkFilm1.UseVisualStyleBackColor = true;
            this.chkFilm1.CheckedChanged += new System.EventHandler(this.chkFilm1_CheckedChanged);
            // 
            // pbFilm3
            // 
            this.pbFilm3.Image = ((System.Drawing.Image)(resources.GetObject("pbFilm3.Image")));
            this.pbFilm3.Location = new System.Drawing.Point(247, 112);
            this.pbFilm3.Name = "pbFilm3";
            this.pbFilm3.Size = new System.Drawing.Size(105, 105);
            this.pbFilm3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbFilm3.TabIndex = 0;
            this.pbFilm3.TabStop = false;
            // 
            // pbFilm2
            // 
            this.pbFilm2.Image = ((System.Drawing.Image)(resources.GetObject("pbFilm2.Image")));
            this.pbFilm2.Location = new System.Drawing.Point(127, 112);
            this.pbFilm2.Name = "pbFilm2";
            this.pbFilm2.Size = new System.Drawing.Size(105, 105);
            this.pbFilm2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbFilm2.TabIndex = 0;
            this.pbFilm2.TabStop = false;
            // 
            // pnlCalatorii
            // 
            this.pnlCalatorii.Controls.Add(this.label5);
            this.pnlCalatorii.Controls.Add(this.lstCalatorii);
            this.pnlCalatorii.Controls.Add(this.chkCal3);
            this.pnlCalatorii.Controls.Add(this.chkCal2);
            this.pnlCalatorii.Controls.Add(this.pbCal1);
            this.pnlCalatorii.Controls.Add(this.chkCal1);
            this.pnlCalatorii.Controls.Add(this.pbCal3);
            this.pnlCalatorii.Controls.Add(this.pbCal2);
            this.pnlCalatorii.Location = new System.Drawing.Point(10, 29);
            this.pnlCalatorii.Name = "pnlCalatorii";
            this.pnlCalatorii.Size = new System.Drawing.Size(67, 29);
            this.pnlCalatorii.TabIndex = 4;
            // 
            // chkCal3
            // 
            this.chkCal3.AutoSize = true;
            this.chkCal3.Location = new System.Drawing.Point(271, 224);
            this.chkCal3.Name = "chkCal3";
            this.chkCal3.Size = new System.Drawing.Size(71, 17);
            this.chkCal3.TabIndex = 4;
            this.chkCal3.Text = "Imi place!";
            this.chkCal3.UseVisualStyleBackColor = true;
            this.chkCal3.Click += new System.EventHandler(this.chkCal1_CheckedChanged);
            // 
            // chkCal2
            // 
            this.chkCal2.AutoSize = true;
            this.chkCal2.Location = new System.Drawing.Point(145, 224);
            this.chkCal2.Name = "chkCal2";
            this.chkCal2.Size = new System.Drawing.Size(71, 17);
            this.chkCal2.TabIndex = 4;
            this.chkCal2.Text = "Imi place!";
            this.chkCal2.UseVisualStyleBackColor = true;
            this.chkCal2.Click += new System.EventHandler(this.chkCal1_CheckedChanged);
            // 
            // pbCal1
            // 
            this.pbCal1.Image = ((System.Drawing.Image)(resources.GetObject("pbCal1.Image")));
            this.pbCal1.Location = new System.Drawing.Point(8, 112);
            this.pbCal1.Name = "pbCal1";
            this.pbCal1.Size = new System.Drawing.Size(105, 105);
            this.pbCal1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCal1.TabIndex = 0;
            this.pbCal1.TabStop = false;
            // 
            // chkCal1
            // 
            this.chkCal1.AutoSize = true;
            this.chkCal1.Location = new System.Drawing.Point(28, 223);
            this.chkCal1.Name = "chkCal1";
            this.chkCal1.Size = new System.Drawing.Size(71, 17);
            this.chkCal1.TabIndex = 4;
            this.chkCal1.Text = "Imi place!";
            this.chkCal1.UseVisualStyleBackColor = true;
            this.chkCal1.CheckedChanged += new System.EventHandler(this.chkCal1_CheckedChanged);
            // 
            // pbCal3
            // 
            this.pbCal3.Image = ((System.Drawing.Image)(resources.GetObject("pbCal3.Image")));
            this.pbCal3.Location = new System.Drawing.Point(247, 112);
            this.pbCal3.Name = "pbCal3";
            this.pbCal3.Size = new System.Drawing.Size(105, 105);
            this.pbCal3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCal3.TabIndex = 0;
            this.pbCal3.TabStop = false;
            // 
            // pbCal2
            // 
            this.pbCal2.Image = ((System.Drawing.Image)(resources.GetObject("pbCal2.Image")));
            this.pbCal2.Location = new System.Drawing.Point(127, 112);
            this.pbCal2.Name = "pbCal2";
            this.pbCal2.Size = new System.Drawing.Size(105, 105);
            this.pbCal2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCal2.TabIndex = 0;
            this.pbCal2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "pnlFilme";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(0, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "pnlCalatorii";
            this.label5.Visible = false;
            // 
            // frmPrezentare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(799, 586);
            this.Controls.Add(this.pnlPasiuni);
            this.Controls.Add(this.pnlCompatibil);
            this.Controls.Add(this.pnlPoze);
            this.DoubleBuffered = true;
            this.Name = "frmPrezentare";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prezentarea mea";
            this.Load += new System.EventHandler(this.frmPrezentare_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbMare)).EndInit();
            this.pnlPoze.ResumeLayout(false);
            this.pnlPoze.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPapagal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCaine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPisica)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.pnlCompatibil.ResumeLayout(false);
            this.pnlCompatibil.PerformLayout();
            this.pnlPasiuni.ResumeLayout(false);
            this.pnlPasiuni.PerformLayout();
            this.pnlLiteratura.ResumeLayout(false);
            this.pnlLiteratura.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLit2)).EndInit();
            this.pnlFilme.ResumeLayout(false);
            this.pnlFilme.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFilm1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFilm3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFilm2)).EndInit();
            this.pnlCalatorii.ResumeLayout(false);
            this.pnlCalatorii.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCal1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCal3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCal2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbMare;
        private System.Windows.Forms.Panel pnlPoze;
        private System.Windows.Forms.Label lblLink;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pb5;
        private System.Windows.Forms.PictureBox pb4;
        private System.Windows.Forms.PictureBox pb8;
        private System.Windows.Forms.PictureBox pb7;
        private System.Windows.Forms.PictureBox pb6;
        private System.Windows.Forms.PictureBox pb3;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.Panel pnlCompatibil;
        private System.Windows.Forms.Panel pnlPasiuni;
        private System.Windows.Forms.ComboBox cboPasiuni;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox lstCalatorii;
        private System.Windows.Forms.ListBox lstFilme;
        private System.Windows.Forms.ListBox lstLiteratura;
        private System.Windows.Forms.PictureBox pbLit1;
        private System.Windows.Forms.PictureBox pbLit2;
        private System.Windows.Forms.PictureBox pbLit3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkLit3;
        private System.Windows.Forms.CheckBox chkLit2;
        private System.Windows.Forms.CheckBox chkLit1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ProgressBar prgCompatibil;
        private System.Windows.Forms.Button btnCalculeaza;
        private System.Windows.Forms.PictureBox pbPisica;
        private System.Windows.Forms.Label lblNegru;
        private System.Windows.Forms.Label lblAlbastru;
        private System.Windows.Forms.Label lblRosu;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCateOrase;
        private System.Windows.Forms.Label lblCateFilme;
        private System.Windows.Forms.Label lblCateCarti;
        private System.Windows.Forms.RadioButton rbPeste;
        private System.Windows.Forms.RadioButton rbPapagal;
        private System.Windows.Forms.RadioButton rbCaine;
        private System.Windows.Forms.RadioButton rbPisica;
        private System.Windows.Forms.PictureBox pbPapagal;
        private System.Windows.Forms.PictureBox pbPeste;
        private System.Windows.Forms.PictureBox pbCaine;
        private System.Windows.Forms.Panel pnlLiteratura;
        private System.Windows.Forms.Panel pnlFilme;
        private System.Windows.Forms.CheckBox chkFilm3;
        private System.Windows.Forms.CheckBox chkFilm2;
        private System.Windows.Forms.PictureBox pbFilm1;
        private System.Windows.Forms.CheckBox chkFilm1;
        private System.Windows.Forms.PictureBox pbFilm3;
        private System.Windows.Forms.PictureBox pbFilm2;
        private System.Windows.Forms.Panel pnlCalatorii;
        private System.Windows.Forms.CheckBox chkCal3;
        private System.Windows.Forms.CheckBox chkCal2;
        private System.Windows.Forms.PictureBox pbCal1;
        private System.Windows.Forms.CheckBox chkCal1;
        private System.Windows.Forms.PictureBox pbCal3;
        private System.Windows.Forms.PictureBox pbCal2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

